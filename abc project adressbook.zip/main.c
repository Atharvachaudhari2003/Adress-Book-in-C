#include <stdio.h>
#include "contact.h"

int main() {
    int choice;
    AddressBook addressBook;
   initialize(&addressBook); // Initialize the address book

    do {
        printf(WHITE"\n📱 ADDRESS BOOK MENU:📲\n"RESET);
        printf(YELLOW"\n1.📞 Create Contact\n"RESET);
        printf(YELLOW"2.📞 Search Contact\n"RESET);
        printf(YELLOW"3.📞 Edit Contact\n"RESET);
        printf(YELLOW"4.📞 Delete Contact\n"RESET);
        printf(YELLOW"5.📞 List all Contacts\n"RESET);
        printf(YELLOW"6.⛔ Exit\n"RESET);
        printf(YELLOW"\nEnter your choice: \n"RESET);
        scanf("%d", &choice);
        getchar();
        
    // if(choice<1 || choice>6)
    // {
    //     while (1)
    //     {
    //         printf("Invalid choice\nEnter your choice:\n");
    //         getchar();
    //         scanf("%d",&choice);
    //             if(choice>=1 && choice<=6)
    //              {
    //                  break;
    //              }

    //     }
        
    // }
   
        switch (choice) {
            case 1:
                createContact(&addressBook);
                break;
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:
                printf(MAGENTA"Select sort criteria:\n"RESET);
                printf(MAGENTA"1. Sort by name & print\n"RESET);
                printf(MAGENTA"2. Sort by phone & print \n"RESET);
                printf(MAGENTA"3. Sort by email & print\n"RESET);
                printf(YELLOW"Enter your choice: "RESET);
                int sortChoice;
                scanf("%d", &sortChoice);
                listContacts(&addressBook, sortChoice);
                break;
            case 6:
                printf(WHITE"Saving and Exiting...\n"RESET);
                saveContactsToFile(&addressBook);
                break;
            default:
                printf(RED"Invalid choice ❌ Please try again.\n"RESET);
        }
    } while (choice != 6);
    
       return 0;
}
